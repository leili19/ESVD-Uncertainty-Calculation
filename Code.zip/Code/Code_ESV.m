
%% build settings

n_sam=1000;

%% read data

T10401raw=readtable("Data_Countries_UN_Population.csv",'ReadRowNames',0,'ReadVariableNames',1);
T10402=readtable("Data_Countries_UN_Codes.csv",'ReadRowNames',0,'ReadVariableNames',1);
T10404=readtable("Data_Countries_UN_GDP.xls",'ReadRowNames',0,'ReadVariableNames',1);
T10405=readtable("Data_Countries_UN_HDI.xlsx",'ReadRowNames',0,'ReadVariableNames',1);
T10406=readtable("Data_Countries_UN_GNI_Atlas.xls",'ReadRowNames',0,'ReadVariableNames',1);
T10407=readtable("Data_Countries_UN_FPer.xls",'ReadRowNames',0,'ReadVariableNames',1);
T10408=readtable("Data_Countries_UN_APer.xls",'ReadRowNames',0,'ReadVariableNames',1);
T10409=readtable("Data_Countries_UN_TProt.xls",'ReadRowNames',0,'ReadVariableNames',1);
T10411=readtable("Data_Countries_UN_MProt.xls",'ReadRowNames',0,'ReadVariableNames',1);
T10412=readtable("Data_Countries_UN_LProt.xls",'ReadRowNames',0,'ReadVariableNames',1);

%% process data

idx=true(1,size(T10404,1));
for i=1:size(T10404,1)
    idxi=ismember(T10402{:,5},T10404{i,2});
    if any(idxi)
        T10404.M49(i)=T10402{idxi,19};
        idx(i)=false;
    end
end
T10404(idx,:)=[];

%% Estimate tranfer from the Ecosystem Services Valuation Database

%% create country dataset 2020

T10401=table();
T10401.M49=unique(T10401raw.M49);

for i=1:size(T10401,1)
    % ISO 3 code
    idxi=T10402{:,19}==T10401.M49(i);
    if any(idxi)
        T10401.CountryCode(i)=T10402{idxi,5}; 
        % WB country name
        idxi=ismember(T10404{:,2},T10401.CountryCode(i));
        if any(idxi)
            T10401.CountryName(i)=T10404{idxi,1};
            %HDI
            idxi=ismember(T10405{:,2},T10401.CountryName(i));
            if any(idxi)
                T10401.HDI(i)=T10405{idxi,3};       
            end        
        end
    end
    %Population stats for 2017
    popcat=unique(T10401raw.Series);
    year=2017;
%      8×1 cell array
% 
%     1={'Population aged 0 to 14 years old (percentage)'      }
%     2={'Population aged 60+ years old (percentage)'          }
%     3={'Population density (ppl/km2)'                        }
%     4={'Population mid-year estimates (millions)'            }
%     5={'Population mid-year estimates for females (millions)'}
%     6={'Population mid-year estimates for males (millions)'  }
%     7={'Sex ratio (males per 100 females)'                   }
%     8={'Surface area (km2)'                          
    indx3=(T10401raw.M49==T10401.M49(i) & ismember(T10401raw.Series,popcat(3)) & T10401raw.Year==year );
    if any(indx3)
        T10401.PopDensity(i) = T10401raw.Value(indx3);
    end
    indx8=(T10401raw.M49==T10401.M49(i) & ismember(T10401raw.Series,popcat(8)) & T10401raw.Year==year );
    if any(indx8)
        T10401.SurfaceArea(i) = T10401raw.Value(indx8)*1000;
    end
end
T10401.CountryCode(find(cellfun(@isempty,T10401.CountryCode)))={''};
T10401.CountryName(find(cellfun(@isempty,T10401.CountryName)))={''};
T10401.HDI(T10401.HDI==0)=NaN;
clear T301raw
% missing data Japan, Sudan
T10401.PopDensity(ismember(T10401.CountryCode,{'JPN'}))=347;
T10401.SurfaceArea(ismember(T10401.CountryCode,{'JPN'}))=377975;
T10401.PopDensity(ismember(T10401.CountryCode,{'SDN'}))=25;
T10401.SurfaceArea(ismember(T10401.CountryCode,{'SDN'}))=1.886 * 10^6;

%GDP
T10401.GDP=NaN(size(T10401,1),1);
for i=1:size(T10401,1)
    indxi=ismember(T10404.CountryCode,T10401.CountryCode(i));  
    if any(indxi)        
        T10401.GDP(i)=T10404.x2002(indxi); %GDP 2002
    end
end
%GNI
T10401.GNI=NaN(size(T10401,1),1);
for i=1:size(T10401.M49,1)
    indxi=ismember(T10406.CountryCode,T10401.CountryCode(i));  
    if any(indxi)        
        T10401.GNI(i)=T10406.x2019(indxi); %GNI 2019
    end
end
%FPer
T10407.FPer=NaN(size(T10401,1),1);
for i=1:size(T10401,1)
    indxi=ismember(T10407{:,2},T10401.CountryCode(i));  
    if any(indxi)        
        T10401.FPer(i)=T10407.x2018(indxi)/100; %G
    end
end
%APer
T10408.APer=NaN(size(T10401,1),1);
for i=1:size(T10401,1)
    indxi=ismember(T10408{:,2},T10401.CountryCode(i));  
    if any(indxi)        
        T10401.APer(i)=T10408.x2018(indxi)/100; %G
    end
end
%TProt
T10409.TProt=zeros(size(T10401,1),1);
for i=1:size(T10401,1)
    indxi=ismember(T10409{:,2},T10401.CountryCode(i));  
    if any(indxi)        
        T10401.TProt(i)=T10409.x2018(indxi)/100; %G
    end
end
%MProt
T10411.MProt=zeros(size(T10401,1),1);
for i=1:size(T10401,1)
    indxi=ismember(T10411{:,2},T10401.CountryCode(i));  
    if any(indxi)        
        T10401.MProt(i)=T10411.x2018(indxi)/100; %G
    end
end
%LProt
T10412.LProt=zeros(size(T10401,1),1);
for i=1:size(T10401,1)
    indxi=ismember(T10412{:,2},T10401.CountryCode(i));  
    if any(indxi)        
        T10401.LProt(i)=T10412.x2018(indxi)/100; %G
    end
end

%data gaps in World Bank Data
T10401.HDI(ismember(T10401.CountryCode,{'ASM'}))=0.827;
T10401.GDP(ismember(T10401.CountryCode,{'ASM'}))=636*10^6;
T10401.GNI(ismember(T10401.CountryCode,{'ASM'}))=4141;
T10401.GVA(ismember(T10401.CountryCode,{'ASM'}))=0.092*636*10^6;
T10401.HDI(ismember(T10401.CountryCode,{'BMU'}))=0.981;
T10401.GDP(ismember(T10401.CountryCode,{'GUM'}))=5.92*10^6;
T10401.GNI(ismember(T10401.CountryCode,{'GUM'}))=29131.59;
T10401.GDP(ismember(T10401.CountryCode,{'CUB'}))=100*10^9;
T10401.GNI(ismember(T10401.CountryCode,{'CUB'}))=7480;
T10401.MProt(isnan(T10401.MProt))=0;

%put countries into HDI tier
for i=1:size(T10401,1)
    if T10401.HDI(i)>=0 && T10401.HDI(i)<0.625
        T10401.HDI_tier(i)=1;
    elseif T10401.HDI(i)>=0.625 && T10401.HDI(i)<0.75
        T10401.HDI_tier(i)=2;
    elseif T10401.HDI(i)>=0.75 && T10401.HDI(i)<=0.89
        T10401.HDI_tier(i)=3;
    elseif T10401.HDI(i)>0.89
        T10401.HDI_tier(i)=4;
    else
        T10401.HDI_tier(i)=NaN;
    end
end

%% ESVD processing

TE=readtable("Data_Land_ESVD-version-December-2020.xlsx",'Sheet','ESVD December 2020','ReadRowNames',0,'ReadVariableNames',1);

Biome_Name=cell(1);
Biome_Name(1)={'Open sea/ocean'};
Biome_Name(2)={'Coral reefs'};
Biome_Name(3)={'Coastal systems (incl. wetlands)'};
Biome_Name(4)={'Inland wetlands'};
Biome_Name(5)={'Rivers and lakes'};
Biome_Name(6)={'Tropical forests'};
Biome_Name(7)={'Temperate forests'};
Biome_Name(8)={'Woodland and shrubland'};
Biome_Name(9)={'Grass-/Rangeland'};
Biome_Name(10)={'Desert'};
Biome_Name(11)={'Tundra'};
Biome_Name(12)={'High mountain & Polar systems'};
Biome_Name(13)={'Inland Un- or Sparsely Vegetated'};
Biome_Name(14)={'Cultivated areas'};
Biome_Name(15)={'Urban Green and Blue Infrastructure'};

Service_Name=cell(1);
Service_Name(1)={'Food'};
Service_Name(2)={'Water'};
Service_Name(3)={'Raw materials'};
Service_Name(4)={'Genetic resources'};
Service_Name(5)={'Medical resources'};
Service_Name(6)={'Ornamental resources'};
Service_Name(7)={'Air quality regulation'};
Service_Name(8)={'Climate regulation'};
Service_Name(9)={'Mod. extreme events'};
Service_Name(10)={'Reg. water flows'};
Service_Name(11)={'Waste treatment'};
Service_Name(12)={'Erosion prevention'};
Service_Name(13)={'Main.soil fertility'};
Service_Name(14)={'Pollination'};
Service_Name(15)={'Biological control'};
Service_Name(16)={'Main. life cycles'};
Service_Name(17)={'Main. genetic diversity'};
Service_Name(18)={'Aesthetic information'};
Service_Name(19)={'Opp. recreation and tourism'};
Service_Name(20)={'Insp. culture, art and design'};
Service_Name(21)={'Spiritual experience'};
Service_Name(22)={'Info. cognitive development'};
Service_Name(23)={'Existence, bequest'};
Service_Name(24)={'Total'};

id_class_ES{1} = 1:6;   % provisioning
id_class_ES{2} = 7:17;  % regulating
id_class_ES{3} = 18:23; % cultural

% process data
id_val = ismember(TE.Valuation_Method,{'VT'}) | ismember(TE.Valuation_Method,{'OT'}) ;% remove VT and OT
TE(id_val,:)=[];
id_val = isnan(TE{:,85}) ; % is not a marginal value
TE(id_val,:)=[];
% fix biome codes
fix1=find(ismember(TE.Biome_1,{'Coastal systems (incl. wetland'}));
for i=1:length(fix1)
    TE.Biome_1(fix1(i))={'Coastal systems (incl. wetlands)'};
end
check=isnan(TE.Biome_Code);
TE.Biome_Code(check & ismember(TE.Biome_1,{'Open sea/ocean'}))=1;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Coral reefs'}))=2;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Coastal systems (incl. wetlands)'}))=3;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Inland wetlands'}))=4;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Rivers and lakes'}))=5;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Tropical forests'}))=6;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Temperate forests'}))=7;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Woodland and shrubland'}))=8;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Grass-/Rangeland'}))=9;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Desert'}))=10;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Tundra'}))=11;
TE.Biome_Code(check & ismember(TE.Biome_1,{'High mountain & Polar systems'}))=12;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Inland Un- or Sparsely Vegetated'}))=13;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Cultivated areas'}))=14;
TE.Biome_Code(check & ismember(TE.Biome_1,{'Urban Green and Blue Infrastructure'}))=15;
% fix TEEB ES codes
check=isnan(TE.TEEB_ES);
TE.TEEB_ES(check & ismember(TE.ES_1,{'Aesthetic information'}))=18;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Air quality regulation'}))=7;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Biological control'}))=15;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Climate regulation'}))=8;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Erosion prevention'}))=12;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Food'}))=1;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Maintenance of genetic diversity'}))=17;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Maintenance of life cycles'}))=16;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Moderation of extreme events'}))=9;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Maintenance of life cycles of migratory species'}))=16;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Opportunities for recreation and tourism'}))=19;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Raw materials'}))=3;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Regulation of water flows'}))=10;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Waste treatment'}))=11;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Water'}))=2;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Genetic resources'}))=4;
TE.TEEB_ES(check & ismember(TE.ES_1,{'Information for cognitive development'}))=22;
TE.TEEB_ES(TE.ValueID==6070003)=24;  % 24 means total
TE.TEEB_ES(TE.ValueID==7070003)=24;  % 24 means total
TE.TEEB_ES(TE.ValueID==4390006)=24;  % 24 means total
TE.TEEB_ES(TE.ValueID==4440001)=24;  % 24 means total
TE.TEEB_ES(TE.TEEB_ES==44256)=1;
TE.TEEB_ES(TE.TEEB_ES==37157)=23;
TE.TEEB_ES(TE.TEEB_ES==37234)=9;
TE.TEEB_ES(TE.TEEB_ES==44462)=23;
TE.TEEB_ES(TE.TEEB_ES==44539)=9;
TE.TEEB_ES(TE.TEEB_ES==27)=23;
% fix country codes
TE.Country_Code_1(TE.ValueID==2580006)={'USA'};
TE.Country_Code_1(TE.ValueID==5820001)={'USA'};
TE.Country_Code_1(TE.ValueID==2640034)={'VNM'};
TE.Country_Code_1(TE.ValueID==6310005)={'VNM'};
% fix lack of uniqueness in study site or other
TE(TE.StudyID==343,:)=[];
TE(TE.StudyID==596,:)=[];
TE(TE.StudyID==147,:)=[];
TE(TE.StudyID==596,:)=[];
TE(TE.ValueID==2960001,:)=[];
TE(TE.ValueID==2730001,:)=[];
TE(TE.ValueID==2720004,:)=[];
TE(TE.ValueID==6530017,:)=[];
TE(TE.ValueID==3590126,:)=[];
TE(TE.ValueID==3610001,:)=[];
TE(TE.ValueID==3590130,:)=[];
TE(TE.ValueID==5820001,:)=[];
TE(TE.ValueID==5510005,:)=[];
TE(TE.ValueID==4040008,:)=[];
TE.Location_Name(TE.StudyID==785)={'Study785Location'};
TE.Location_Name(TE.StudyID==786)={'Study786Location'};
TE.Location_Name(TE.StudyID==305)={'Study305Location'};
TE.Location_Name(TE.StudyID==695)={'Study695LocationA'};

idhasplit=unique(TE.Site_Area(TE.StudyID==159));
for i=1:length(idhasplit)
    TE.Location_Name(TE.StudyID==159 & TE.Site_Area==idhasplit(i))={['Study159Location_' num2str(i)]};
end
idhasplit=unique(TE.Site_Area(TE.StudyID==780));
for i=1:length(idhasplit)
    TE.Location_Name(TE.StudyID==780 & TE.Site_Area==idhasplit(i))={['Study780Location_' num2str(i)]};
end

% remove biomes not used in study

TE(ismember(TE.Biome_Code,[1, 10:15]),:)=[];

% Examine biomes services for outliers
for k=2:9
    ES.Global.Biome(k).Name=Biome_Name{k};
    idk= TE.Biome_Code==k;
    if any(idk)
        figure
        set(gcf,'Color',[1 1 1]);
        ES.Global.Biome(k).Value=TE{idk,85};
        for m=1:24
            ES.Global.Biome(k).Service(m).Value=TE{idk & TE.TEEB_ES==m,85};
            ES.Global.Biome(k).Service(m).Name = Service_Name{m};
            if any(idk & TE.TEEB_ES==m)
                a=min(log10(ES.Global.Biome(k).Value));
                b=max(log10(ES.Global.Biome(k).Value));
                subplot(6,4,m);
                histogram(log10(ES.Global.Biome(k).Service(m).Value),10,'FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]);
                xlim([a b]);
                xlabel(['log(ESV) m=' num2str(m) ' - ' ES.Global.Biome(k).Service(m).Name]);
            end
        end  
        sgtitle(['Biome k=' num2str(k) ' (' Biome_Name{k} ')'])
    end
end

%outlier removal

Outlier_Table = table();
OUTN=20; 

%k=2 coastal systems
k=2;

m=9;
thres=10^5;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end

m=12;
thres=10^5;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end


m=19;
thres=10^6;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end


m=22;
thres=10^4;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end

m=23;
thres=10^5;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end


%k=3 coastal systems
k=3;

m=8;
thres=10^6;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end


m=9;
thres=10^6;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end


m=16;
thres=10^5;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end

m=17;
thres=10^6;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end


m=19;
thres=10^6;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end

m=23;
thres=10^6;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end


m=24;
thres=10^6;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end


%k=4 inland wetlands
k=4;

m=8;
thres=10^5;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end


m=10;
thres=10^4;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end

m=17;
thres=10^5;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end

%k=5 lakes and rivers
k=5;

m=1;
thres=10^5;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end

m=11;
thres=10^4;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end


m=19;
thres=10^6;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end

%k=6 tropical forests
k=6;

m=5;
thres=10^6;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end

%k=7 temperate forests
k=7;

m=2;
thres=10^6;

indkm = sub2indB([size(unique(TE.Biome_Code),1),size(unique(TE.TEEB_ES),1)],[k,m]);
Outlier_Table.Biome_Code(indkm) =k;
Outlier_Table.TEEB_ES(indkm) = m ;
Outlier_Table.Sample_Size(indkm) = sum(TE.Biome_Code==k & TE.TEEB_ES==m);
if Outlier_Table.Sample_Size(indkm) < OUTN
    Outlier_Table.Method(indkm)={'P Window'};
    Outlier_Table.Upper_Threshold(indkm) = thres;
    pera= sum((ES.Global.Biome(k).Service(m).Value > Outlier_Table.Upper_Threshold(indkm)))/length(ES.Global.Biome(k).Service(m).Value);
    vala = prctile(ES.Global.Biome(k).Service(m).Value,100*pera);
    Outlier_Table.Lower_Threshold(indkm) = vala;
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} > Outlier_Table.Upper_Threshold(indkm),:)=[];
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & TE{:,85} < vala,:)=[];
end
if Outlier_Table.Sample_Size(indkm) >= OUTN
    Outlier_Table.Method(indkm)={'MAD'};
    X=log10(TE{TE.Biome_Code==k & TE.TEEB_ES==m,85});
    OUTL = abs(X-median(X))/mad(X) > 2;
    A = X(OUTL);
    Outlier_Table.Upper_Threshold(indkm) = NaN;
    Outlier_Table.Lower_Threshold(indkm) = NaN;
    if any(A>median(X))
    Outlier_Table.Upper_Threshold(indkm) = 10.^min(A(A>median(X)));
    end
    if any(A<median(X))
    Outlier_Table.Lower_Threshold(indkm) = 10.^max(A(A<median(X)));
    end
    TE(TE.Biome_Code==k & TE.TEEB_ES==m & ismember(log10(TE{:,85}),A),:)=[];
end

%clean up
Outlier_Table(Outlier_Table.Biome_Code==0,:)=[];
ESOld=ES;

%reassemble biome values in ES after outliers gone
for k=2:9
    ES.Global.Biome(k).Name=Biome_Name{k};
    idk= TE.Biome_Code==k;
    if any(idk)
        ES.Global.Biome(k).Value=TE{idk,85};
        for m=1:24
            ES.Global.Biome(k).Service(m).Value=TE{idk & TE.TEEB_ES==m,85};
            ES.Global.Biome(k).Service(m).Name = Service_Name{m};
        end
    end
end

%% ESVD regressions examine country and biome structure

extract1=@(x)(floor(10.00001*(x-floor(x))));

%country
id_val=unique(TE.Country_Code_1);
for i=1:length(id_val)
    id_vali = ismember(TE.Country_Code_1,id_val(i));
    i101=find(ismember(T10401.CountryCode,id_val(i)));
    ES.Country(i101).Name=id_val(i);
    %biomes with valuation in country i
    idbm=unique(TE.Biome_Code(id_vali));
    for k=1:length(idbm)
        id_valik = id_vali & TE.Biome_Code==idbm(k);
        ES.Country(i101).Biome(idbm(k)).Name=idbm(k);
        %ecosystems in biome k  with valuation in country i
        idec=unique(TE.Ecosystem_Code(id_valik));
        for j=1:length(idec)
            id_valikj=id_valik & TE.Ecosystem_Code==idec(j);
            ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Name=idbm(k)+0.1*extract1(idec(j));
            %services in ecosystem j in biome k  with valuation in country i
            idsv=unique(TE.TEEB_ES(id_valikj));
            for m=1:length(idsv)
                id_valikjm = id_valikj & TE.TEEB_ES==idsv(m);
                ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Service(idsv(m)).Name=idsv(m);
                ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Service(idsv(m)).Value=TE{id_valikjm,85};
            end
            %sum random variable services to ecosystem
            EValue=zeros(1,n_sam);
            for p=1:n_sam %(n_sam-nt)
                TValue=zeros(length(idsv),1);
                for m=1:length(idsv)
                    %choose a value at random from ecosystem service
                    n=length(ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Service(idsv(m)).Value);
                    if ~(n==0)
                        TValue(m,1)=ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Service(idsv(m)).Value(randi(n));
                    end
                end
                EValue(1,p) = sum(TValue);
            end
            ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Value=EValue;
        end
        %sum random variable services to biome
        EValue=zeros(1,n_sam);
        for p=1:n_sam %(n_sam-nt)
            TValue=zeros(length(idec),1);
            for m=1:length(idec)
                %choose a value at random from ecosystem service
                n=length(ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Value);
                if ~(n==0)
                    TValue(m,1)=ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Value(randi(n));
                end
            end
            EValue(1,p) = sum(TValue);
        end
        ES.Country(i101).Biome(idbm(k)).Value=EValue;   
        ES.Country(i101).Biome(idbm(k)).LMean=mean(log10(EValue));   
        ES.Country(i101).Biome(idbm(k)).LStd=std(log(EValue)); 
    end
    ES.Country(i101).X = [log10(T10401.PopDensity(i101)) log10(T10401.GNI(i101)) T10401.HDI(i101) T10401.FPer(i101) T10401.APer(i101) T10401.MProt(i101) T10401.LProt(i101)];
    ES.Country(i101).HDI = 0;
    if T10401.HDI(i101)>0 && T10401.HDI(i101)<0.625 %low development
        ES.Country(i101).HDI=1;
    elseif T10401.HDI(i101)>=0.625 && T10401.HDI(i101)<0.75 %moderate development
        ES.Country(i101).HDI=2;
    elseif T10401.HDI(i101)>=0.75 && T10401.HDI(i101)<0.89
        ES.Country(i101).HDI=3; %high development
    elseif T10401.HDI(i101)>=0.89
        ES.Country(i101).HDI=4; %very high development
    end
end

%build table from structure for analysis

EST=table();
counter=0;
for k=2:9
    for i=1:length(ES.Country)
        if ~isempty(ES.Country(i).Biome)
            idbm=[ES.Country(i).Biome.Name]==k;
            if any(idbm)
                counter=counter+1;
                EST.Biome(counter)=k;
                EST.Country(counter)=i;
                EST.HDI(counter)=ES.Country(i).HDI;
            end
        end
    end
end

%form country values for regression
for i=1:size(EST,1)
   EST.Y(i)= ES.Country(EST.Country(i)).Biome(EST.Biome(i)).LMean;
   EST.Ystd(i)= ES.Country(EST.Country(i)).Biome(EST.Biome(i)).LStd;
   EST.X(i,:)=ES.Country(EST.Country(i)).X;
end

EST(EST.HDI==0,:)=[];

spl={[],[6,6],[8,7],[7,6],[5,5],[4,4]};
%plot country values
for k=2:6
   figure
   set(gcf,'Color',[1 1 1]); 
   idbm=find(EST.Biome==k);
   minV= min(log10(ES.Global.Biome(k).Value));
   if minV==-Inf
      minV=-4; 
   end
   maxV= max(log10(ES.Global.Biome(k).Value));
   for i=1:length(idbm)
        subplot(spl{k}(1),spl{k}(2),i);
        id_val=EST.Country(idbm(i));
        histogram(log10(ES.Country(id_val).Biome(k).Value),10,'Normalization','pdf','BinWidth',(maxV-minV)/20,'FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]);
        y=ylim;
        xlim([minV maxV]);
        xlabel(['log(ESV) ' T10401.CountryName(ismember(T10401.CountryCode,ES.Country(id_val).Name))]);         
        hold on
        plot([ES.Country(id_val).Biome(k).LMean ES.Country(id_val).Biome(k).LMean],[y(1) y(2)],'k--','LineWidth',2);
   end
   sgtitle(['Biome k=' num2str(k) ' (' Biome_Name{k} ')']) 
end

%examine residuals k=7,8,9
idk=EST.Biome==7 | EST.Biome==8 | EST.Biome==9;
idv=unique(EST.Country(idk));
   figure
   set(gcf,'Color',[1 1 1]); 
      minV= min(log10([ES.Global.Biome(7).Value;ES.Global.Biome(8).Value;ES.Global.Biome(9).Value]));
   if minV==-Inf
      minV=-4; 
   end
   maxV= max(log10([ES.Global.Biome(7).Value;ES.Global.Biome(8).Value;ES.Global.Biome(9).Value]));
   n=size(EST,1);
for i=1:length(idv)
   EValue=[];
   for k=7:9
       if size(ES.Country(idv(i)).Biome,2) >=k 
       EValue=[EValue,ES.Country(idv(i)).Biome(k).Value];
       end
   end   
       EST.Biome(n+i)=789;
       EST.Country(n+i) = idv(i);
       EST.HDI(n+i)=ES.Country(idv(i)).HDI;
       EST.Y(n+i)=mean(log10(EValue));
       EST.Ystd(n+i)=std(log10(EValue));
       EST.X(n+i,:)=ES.Country(idv(i)).X;
        subplot(4,4,i);
        histogram(log10(EValue),10,'Normalization','pdf','BinWidth',(maxV-minV)/33,'FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]);
        y=ylim;
        xlim([minV maxV]);
        xlabel(['log(ESV) ' T10401.CountryName(ismember(T10401.CountryCode,ES.Country(idv(i)).Name))]);         
        hold on
        plot([EST.Y(n+i) EST.Y(n+i)],[y(1) y(2)],'k--','LineWidth',2);
end
   sgtitle('Biome k=7,8,9') 


%stat table

Regression_Stat=table();
for k=2:6
id=EST.Biome==k;
A = EST.Y(id);
%mean 
idk=k-1;
Regression_Stat.Biome(idk) = k;
Regression_Stat.Stat(idk) = {'Mean'};
Regression_Stat.N(idk) = sum(id);
Regression_Stat.Mean(idk) = mean(A);
Regression_Stat.Std(idk) = std(A);
Regression_Stat.Min(idk) = min(A);
Regression_Stat.Max(idk) = max(A);
%std
id = id & EST.Ystd > 10^(-6);
A = EST.Ystd(id);
idk=6+k-1;
Regression_Stat.Biome(idk) = k;
Regression_Stat.Stat(idk) = {'Std'};
Regression_Stat.N(idk) = sum(id);
Regression_Stat.Mean(idk) = mean(A);
Regression_Stat.Std(idk) = std(A);
Regression_Stat.Min(idk) = min(A);
Regression_Stat.Max(idk) = max(A);
end

id=EST.Biome==789;
A = EST.Y(id);
%mean 
idk=6;
Regression_Stat.Biome(idk) = 789;
Regression_Stat.Stat(idk) = {'Mean'};
Regression_Stat.N(idk) = sum(id);
Regression_Stat.Mean(idk) = mean(A);
Regression_Stat.Std(idk) = std(A);
Regression_Stat.Min(idk) = min(A);
Regression_Stat.Max(idk) = max(A);
%std
id = id & EST.Ystd > 10^(-6);
A = EST.Ystd(id);
idk=12;
Regression_Stat.Biome(idk) = 789;
Regression_Stat.Stat(idk) = {'Std'};
Regression_Stat.N(idk) = sum(id);
Regression_Stat.Mean(idk) = mean(A);
Regression_Stat.Std(idk) = std(A);
Regression_Stat.Min(idk) = min(A);
Regression_Stat.Max(idk) = max(A);

Regression_Stat{:,3:end} = round(Regression_Stat{:,3:end},2);


%% ESVD regressions examine country and biome structure

%store regression results
mdl=cell(7,1);
mdlr=cell(7,2);
mds=cell(7,1);
mdsr=cell(7,2);

std_crit = 10^(-3);

%k=2 regression
k=2;
idk=EST.Biome==k;
mdl{k,1} = fitlm(EST.X(idk,:),EST.Y(idk)); 
mdl{k,1} %examine regression model R^2=0.355 

% reduced model
mdlr{k,2} = logical([1 0 0 0 0 0 0]); % log(PDen), log(GNI), HDI, Aper, FPer, MProt, LProt
mdlr{k,1} = fitlm(EST.X(idk,mdlr{k,2}),EST.Y(idk)); 
mdlr{k,1} % R^2=0.26 (log(PDen)

% model for std
mds{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,:),EST.Ystd(idk & EST.Ystd > std_crit));
mds{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,:),log(EST.Ystd(idk & EST.Ystd > std_crit)));
mds{k,1} % R^2=0.102
mdsr{k,2}=logical([0 0 0 0 0 0 0]); %no significance
mdsr{k,1} = fitlm(EST.X(idk & EST.Ystd > std_crit,mdsr{k,2}),EST.Ystd(idk & EST.Ystd > std_crit));
mdsr{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,mdsr{k,2}),log(EST.Ystd(idk & EST.Ystd > std_crit)));
mdsr{k,1}

% residuals
figure
set(gcf,'Color',[1 1 1]);
resY=  mdl{k,1}.Residuals{:,1}; % residuals
histogram(resY,20,'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]); %examine residuals
Xdata=linspace(min(resY),max(resY),100);
hold on;
%normcdf(1,mean(resY),std(resY),'upper')
plot(Xdata,normpdf(Xdata,mean(resY),std(resY)),'k');
xlabel('Residuals for Biome k=2 (Coral Reefs)');

%k=3 regression
k=3;
idk=EST.Biome==k;
mdl{k,1} = fitlm(EST.X(idk,:),EST.Y(idk)); 
mdl{k,1} %examine regression model R^2=0.166

% reduced model
mdlr{k,2} = logical([0 0 1 0 0 0 0]); % log(PDen), log(GNI), HDI, Aper, FPer, MProt, LProt
mdlr{k,1} = fitlm(EST.X(idk,mdlr{k,2}),EST.Y(idk)); 
mdlr{k,1} % R^2=0.065( HDI )

% model for std
mds{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,:),EST.Ystd(idk & EST.Ystd > std_crit));
mds{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,:),log(EST.Ystd(idk & EST.Ystd > std_crit)));
mds{k,1} % R^2=0.455
mdsr{k,2}=logical([1 1 1 0 0 0 0]); %no significance
mdsr{k,1} = fitlm(EST.X(idk & EST.Ystd > std_crit,mdsr{k,2}),EST.Ystd(idk & EST.Ystd > std_crit));
mdsr{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,mdsr{k,2}),log(EST.Ystd(idk & EST.Ystd > std_crit)));
mdsr{k,1} % R^2=0.251 ( log(PDen), log(GNI), HDI 

% residuals
figure
set(gcf,'Color',[1 1 1]);
resY=  mdl{k,1}.Residuals{:,1}; % residuals
histogram(resY,20,'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]); %examine residuals
Xdata=linspace(min(resY),max(resY),100);
hold on;
%normcdf(1,mean(resY),std(resY),'upper')
plot(Xdata,normpdf(Xdata,mean(resY),std(resY)),'k');
xlabel('Residuals for Biome k=3 (Coastal Systems)');

%k=4 regression 
k=4;
idk=EST.Biome==k;
mdl{k,1} = fitlm(EST.X(idk,:),EST.Y(idk)); 
mdl{k,1} %examine regression model R^2=0.443

% reduced model
mdlr{k,2} = logical([0 1 0 1 1 0 1]); % log(PDen), log(GNI), HDI, Aper, FPer, MProt, LProt
mdlr{k,1} = fitlm(EST.X(idk,mdlr{k,2}),EST.Y(idk)); 
mdlr{k,1} % R^2=0.244(  Aper, FPer, LProt )

% model for std
mds{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,:),EST.Ystd(idk & EST.Ystd > std_crit));
mds{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,:),log(EST.Ystd(idk & EST.Ystd > std_crit)));
mds{k,1} % R^2=0.377
mdsr{k,2}=logical([0 1 1 0 0 0 0]); %no significance
mdsr{k,1} = fitlm(EST.X(idk & EST.Ystd > std_crit,mdsr{k,2}),EST.Ystd(idk & EST.Ystd > std_crit));
mdsr{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,mdsr{k,2}),log(EST.Ystd(idk & EST.Ystd > std_crit)));
mdsr{k,1} % R^2=0.232 ( log(PDen), HDI 


% residuals
figure
set(gcf,'Color',[1 1 1]);
resY=  mdl{k,1}.Residuals{:,1}; % residuals
histogram(resY,20,'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]); %examine residuals
Xdata=linspace(min(resY),max(resY),100);
hold on;
%normcdf(1,mean(resY),std(resY),'upper')
plot(Xdata,normpdf(Xdata,mean(resY),std(resY)),'k');
xlabel('Residuals for Biome k=4 (Inland Wetlands)');

%k=5 regression
k=5;
idk=EST.Biome==k;
mdl{k,1} = fitlm(EST.X(idk,:),EST.Y(idk)); 
mdl{k,1} %examine regression model R^2=0.206

% reduced model
mdlr{k,2} = logical([0 0 0 1 0 0 0]); % log(PDen), log(GNI), HDI, Aper, FPer, MProt, LProt
mdlr{k,1} = fitlm(EST.X(idk,mdlr{k,2}),EST.Y(idk)); 
mdlr{k,1} % R^2=0.122   Aper

% model for std
mds{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,:),EST.Ystd(idk & EST.Ystd > std_crit));
mds{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,:),log(EST.Ystd(idk & EST.Ystd > std_crit)));
mds{k,1} % 
mdsr{k,2}=logical([0 0 1 0 0 0 0]); %no significance
mdsr{k,1} = fitlm(EST.X(idk & EST.Ystd > std_crit,mdsr{k,2}),EST.Ystd(idk & EST.Ystd > std_crit));
mdsr{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,mdsr{k,2}),log(EST.Ystd(idk & EST.Ystd > std_crit)));
mdsr{k,1} % R^2=0.596 ,  HDI 

% residuals
figure
set(gcf,'Color',[1 1 1]);
resY=  mdl{k,1}.Residuals{:,1}; % residuals
histogram(resY,20,'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]); %examine residuals
Xdata=linspace(min(resY),max(resY),100);
hold on;
%normcdf(1,mean(resY),std(resY),'upper')
plot(Xdata,normpdf(Xdata,mean(resY),std(resY)),'k');
xlabel('Residuals for Biome k=5 (Lakes and Rivers)');

%k=6 regression
k=6;
idk=EST.Biome==k;
mdl{k,1} = fitlm(EST.X(idk,:),EST.Y(idk)); 
mdl{k,1} %examine regression model R^2=0.411

% reduced model
mdlr{k,2} = logical([0 1 0 0 0 0 0]); % log(PDen), log(GNI), HDI, Aper, FPer, MProt, LProt
mdlr{k,1} = fitlm(EST.X(idk,mdlr{k,2}),EST.Y(idk)); 
mdlr{k,1} % R^2=0.252  GNI

% model for std
mds{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,:),EST.Ystd(idk & EST.Ystd > std_crit));
mds{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,:),log(EST.Ystd(idk & EST.Ystd > std_crit)));
mds{k,1} % 
mdsr{k,2}=logical([1 1 0 0 0 0 0]); %no significance
mdsr{k,1} = fitlm(EST.X(idk & EST.Ystd > std_crit,mdsr{k,2}),EST.Ystd(idk & EST.Ystd > std_crit));
mdsr{k,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,mdsr{k,2}),log(EST.Ystd(idk & EST.Ystd > std_crit)));
mdsr{k,1}


% residuals
figure
set(gcf,'Color',[1 1 1]);
resY=  mdl{k,1}.Residuals{:,1}; % residuals
histogram(resY,20,'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]); %examine residuals
Xdata=linspace(min(resY),max(resY),100);
hold on;
%normcdf(1,mean(resY),std(resY),'upper')
plot(Xdata,normpdf(Xdata,mean(resY),std(resY)),'k');
xlabel('Residuals for Biome k=6 (Tropical Forests)');

%k=789 regression
k=789;
idk=EST.Biome==k;
mdl{7,1} = fitlm(EST.X(idk,:),EST.Y(idk)); 
mdl{7,1} %examine regression model R^2=0.411

% reduced model
mdlr{7,2} = logical([1 0 0 0 0 0 0]); % log(PDen), log(GNI), HDI, Aper, FPer, MProt, LProt
mdlr{7,1} = fitlm(EST.X(idk,mdlr{7,2}),EST.Y(idk)); 
mdlr{7,1} % R^2=0.434 log(PDen)

% model for std
mds{7,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,:),EST.Ystd(idk & EST.Ystd > std_crit));
mds{7,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,:),log(EST.Ystd(idk & EST.Ystd > std_crit)));
mds{7,1} % 
mdsr{7,2}=logical([1 1 0 0 0 0 0]); %no significance
mdsr{7,1} = fitlm(EST.X(idk & EST.Ystd > std_crit,mdsr{7,2}),EST.Ystd(idk & EST.Ystd > std_crit));
mdsr{7,1}=fitlm(EST.X(idk & EST.Ystd > std_crit,mdsr{7,2}),log(EST.Ystd(idk & EST.Ystd > std_crit)));
mdsr{7,1}

% residuals
figure
set(gcf,'Color',[1 1 1]);
resY=  mdl{7,1}.Residuals{:,1}; % residuals
histogram(resY,20,'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]); %examine residuals
Xdata=linspace(min(resY),max(resY),100);
hold on;
%normcdf(1,mean(resY),std(resY),'upper')
plot(Xdata,normpdf(Xdata,mean(resY),std(resY)),'k');
xlabel('Residuals for Biome k=7,8,9 (Temperate Forests, Shrubland and Grasslands)');

Regression=struct();

% model mu
s=1;
Regression(s).Results=table();

for k=2:7
    Regression(s).Results.Biome(k)=k;
    if k==7
        Regression(s).Results.Biome(k)=789;
    end
    Regression(s).Results.N(k) = mdl{k}.NumObservations;
    Regression(s).Results.DoF(k) = mdl{k}.NumObservations-mdl{k}.NumPredictors;
    Regression(s).Results.Rsqr(k) = mdl{k}.Rsquared.Ordinary;
    Regression(s).Results.Rsqr_A(k) = mdl{k}.Rsquared.Adjusted;
    Regression(s).Results.FitP(k) = mdl{k}.ModelFitVsNullModel.Pvalue;
    Regression(s).Results.Coeff(k,:) = mdl{k}.Coefficients.Estimate';
    Regression(s).Results.pValue(k,:) = mdl{k}.Coefficients.pValue';
    Regression(s).Results.Resstd(k,:) = std(mdl{k,1}.Residuals{:,1});
    Regression(s).Results.OverEstimate(k) = normcdf(1,mean(mdl{k,1}.Residuals{:,1}),std(mdl{k,1}.Residuals{:,1}),'upper');
end   

% model mu reduced
s=2;
Regression(s).Results=table();

for k=2:7
    Regression(s).Results.Biome(k)=k;
    if k==7
        Regression(s).Results.Biome(k)=789;
    end
    Regression(s).Results.N(k) = mdlr{k}.NumObservations;
    Regression(s).Results.DoF(k) = mdlr{k}.NumObservations-mdlr{k}.NumPredictors;
    Regression(s).Results.Rsqr(k) = mdlr{k}.Rsquared.Ordinary;
    Regression(s).Results.Rsqr_A(k) = mdlr{k}.Rsquared.Adjusted;
    Regression(s).Results.FitP(k) = mdlr{k}.ModelFitVsNullModel.Pvalue;
    Regression(s).Results.Coeff(k,:) = NaN(1,8);
    Regression(s).Results.Coeff(k,[true mdlr{k,2}]) = mdlr{k}.Coefficients.Estimate(1:sum(mdlr{k,2})+1)';
    Regression(s).Results.pValue(k,:) = NaN(1,8);
    Regression(s).Results.pValue(k,[true mdlr{k,2}]) = mdlr{k}.Coefficients.pValue(1:sum(mdlr{k,2})+1)';
    Regression(s).Results.Resstd(k,:) = std(mdlr{k,1}.Residuals{:,1});
    Regression(s).Results.OverEstimate(k) = normcdf(1,mean(mdlr{k,1}.Residuals{:,1}),std(mdlr{k,1}.Residuals{:,1}),'upper');
end   

% model sigma
s=3;
Regression(s).Results=table();

for k=2:7
    Regression(s).Results.Biome(k)=k;
    if k==7
        Regression(s).Results.Biome(k)=789;
    end
    Regression(s).Results.N(k) = mds{k}.NumObservations;
    Regression(s).Results.DoF(k) = mds{k}.NumObservations-mds{k}.NumPredictors;
    Regression(s).Results.Rsqr(k) = mds{k}.Rsquared.Ordinary;
    Regression(s).Results.Rsqr_A(k) = mds{k}.Rsquared.Adjusted;
    Regression(s).Results.FitP(k) = mds{k}.ModelFitVsNullModel.Pvalue;
    Regression(s).Results.Coeff(k,:) = mds{k}.Coefficients.Estimate';
    Regression(s).Results.pValue(k,:) = mds{k}.Coefficients.pValue';
    Regression(s).Results.Resstd(k,:) = std(mds{k,1}.Residuals{:,1});
end   

% model sigma reduced
s=4;
Regression(s).Results=table();

for k=2:7
    Regression(s).Results.Biome(k)=k;
    if k==7
        Regression(s).Results.Biome(k)=789;
    end
    Regression(s).Results.N(k) = mdsr{k}.NumObservations;
    Regression(s).Results.DoF(k) = mdsr{k}.NumObservations-mdsr{k}.NumPredictors;
    Regression(s).Results.Rsqr(k) = mdsr{k}.Rsquared.Ordinary;
    Regression(s).Results.Rsqr_A(k) = mdsr{k}.Rsquared.Adjusted;
    Regression(s).Results.FitP(k) = mdsr{k}.ModelFitVsNullModel.Pvalue;
    Regression(s).Results.Coeff(k,:) = NaN(1,8);
    Regression(s).Results.Coeff(k,[true mdsr{k,2}]) = mdsr{k}.Coefficients.Estimate(1:sum(mdsr{k,2})+1)';
    Regression(s).Results.pValue(k,:) = NaN(1,8);
    Regression(s).Results.pValue(k,[true mdsr{k,2}]) = mdsr{k}.Coefficients.pValue(1:sum(mdsr{k,2})+1)';
    Regression(s).Results.Resstd(k,:) = std(mdsr{k,1}.Residuals{:,1});
end 

%% ESVD Global values

% Examine biomes services for low study removal
for k=2:9
    ES.Global.Biome(k).Name=Biome_Name{k};
    idk= TE.Biome_Code==k;
    if any(idk)
        figure
        set(gcf,'Color',[1 1 1]);
        ES.Global.Biome(k).Value=TE{idk,85};
        for m=1:24
            ES.Global.Biome(k).Service(m).Value=TE{idk & TE.TEEB_ES==m,85};
            ES.Global.Biome(k).Service(m).Name = Service_Name{m};
            if any(idk & TE.TEEB_ES==m)
                a=min(log10(ES.Global.Biome(k).Value));
                b=max(log10(ES.Global.Biome(k).Value));
                subplot(6,4,m);
                histogram(log10(ES.Global.Biome(k).Service(m).Value),10,'FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]);
                xlim([a b]);
                xlabel(['log(ESV) m=' num2str(m) ' - ' ES.Global.Biome(k).Service(m).Name]);
            end
        end  
        sgtitle(['Biome k=' num2str(k) ' (' Biome_Name{k} ')']) 
    end
end

%k=2 low study number removal
TE(TE.Biome_Code==2 & TE.TEEB_ES==6,:)=[];
TE(TE.Biome_Code==2 & TE.TEEB_ES==11,:)=[];
TE(TE.Biome_Code==2 & TE.TEEB_ES==17,:)=[];
%TE(TE.Biome_Code==2 & TE.TEEB_ES==20,:)=[];

%k=3 low study number removal
TE(TE.Biome_Code==3 & TE.TEEB_ES==4,:)=[];
TE(TE.Biome_Code==3 & TE.TEEB_ES==5,:)=[];
TE(TE.Biome_Code==3 & TE.TEEB_ES==7,:)=[];
TE(TE.Biome_Code==3 & TE.TEEB_ES==15,:)=[];
TE(TE.Biome_Code==3 & TE.TEEB_ES==21,:)=[];
%TE(TE.Biome_Code==3 & TE.TEEB_ES==22,:)=[];

%k=4 low study number removal
TE(TE.Biome_Code==4 & TE.TEEB_ES==4,:)=[];
TE(TE.Biome_Code==4 & TE.TEEB_ES==5,:)=[];
TE(TE.Biome_Code==4 & TE.TEEB_ES==7,:)=[];
TE(TE.Biome_Code==4 & TE.TEEB_ES==13,:)=[];
TE(TE.Biome_Code==4 & TE.TEEB_ES==15,:)=[];
%TE(TE.Biome_Code==4 & TE.TEEB_ES==16,:)=[];
%TE(TE.Biome_Code==4 & TE.TEEB_ES==17,:)=[];
TE(TE.Biome_Code==4 & TE.TEEB_ES==21,:)=[];
TE(TE.Biome_Code==4 & TE.TEEB_ES==22,:)=[];
TE(TE.Biome_Code==4 & TE.TEEB_ES==23,:)=[];

%k=5 low study number removal
TE(TE.Biome_Code==5 & TE.TEEB_ES==7,:)=[];
TE(TE.Biome_Code==5 & TE.TEEB_ES==8,:)=[];
TE(TE.Biome_Code==5 & TE.TEEB_ES==9,:)=[];
TE(TE.Biome_Code==5 & TE.TEEB_ES==11,:)=[];
TE(TE.Biome_Code==5 & TE.TEEB_ES==13,:)=[];
TE(TE.Biome_Code==5 & TE.TEEB_ES==15,:)=[];
TE(TE.Biome_Code==5 & TE.TEEB_ES==16,:)=[];
TE(TE.Biome_Code==5 & TE.TEEB_ES==17,:)=[];
TE(TE.Biome_Code==5 & TE.TEEB_ES==20,:)=[];
TE(TE.Biome_Code==5 & TE.TEEB_ES==21,:)=[];
TE(TE.Biome_Code==5 & TE.TEEB_ES==22,:)=[];

%k=6 low study number removal
TE(TE.Biome_Code==6 & TE.TEEB_ES==10,:)=[];
TE(TE.Biome_Code==6 & TE.TEEB_ES==13,:)=[];
%TE(TE.Biome_Code==6 & TE.TEEB_ES==14,:)=[];
TE(TE.Biome_Code==6 & TE.TEEB_ES==17,:)=[];
TE(TE.Biome_Code==6 & TE.TEEB_ES==20,:)=[];

%k=7 low study number removal
TE(TE.Biome_Code==7 & TE.TEEB_ES==2,:)=[];
TE(TE.Biome_Code==7 & TE.TEEB_ES==9,:)=[];
TE(TE.Biome_Code==7 & TE.TEEB_ES==10,:)=[];
TE(TE.Biome_Code==7 & TE.TEEB_ES==13,:)=[];
TE(TE.Biome_Code==7 & TE.TEEB_ES==14,:)=[];
TE(TE.Biome_Code==7 & TE.TEEB_ES==16,:)=[];
TE(TE.Biome_Code==7 & TE.TEEB_ES==18,:)=[];
TE(TE.Biome_Code==7 & TE.TEEB_ES==19,:)=[];
TE(TE.Biome_Code==7 & TE.TEEB_ES==22,:)=[];

%k=8 low study removal
TE(TE.Biome_Code==8 & TE.TEEB_ES==1,:)=[];
TE(TE.Biome_Code==8 & TE.TEEB_ES==2,:)=[];
TE(TE.Biome_Code==8 & TE.TEEB_ES==10,:)=[];
TE(TE.Biome_Code==8 & TE.TEEB_ES==12,:)=[];
TE(TE.Biome_Code==8 & TE.TEEB_ES==15,:)=[];
TE(TE.Biome_Code==8 & TE.TEEB_ES==18,:)=[];
TE(TE.Biome_Code==8 & TE.TEEB_ES==19,:)=[];
TE(TE.Biome_Code==8 & TE.TEEB_ES==22,:)=[];
TE(TE.Biome_Code==8 & TE.TEEB_ES==23,:)=[];

%k=9 low study removal
TE(TE.Biome_Code==9 & TE.TEEB_ES==1,:)=[];
TE(TE.Biome_Code==9 & TE.TEEB_ES==2,:)=[];
TE(TE.Biome_Code==9 & TE.TEEB_ES==12,:)=[];
TE(TE.Biome_Code==9 & TE.TEEB_ES==13,:)=[];
TE(TE.Biome_Code==9 & TE.TEEB_ES==16,:)=[];
TE(TE.Biome_Code==9 & TE.TEEB_ES==23,:)=[];

%reassemble biome values after outliers and low studies gone
for k=2:9
    ES.Global.Biome(k).Name=Biome_Name{k};
    idk= TE.Biome_Code==k;
    if any(idk)
        figure
        set(gcf,'Color',[1 1 1]);
        ES.Global.Biome(k).Value=TE{idk,85};
        a=min(log10(ESOld.Global.Biome(k).Value));
        b=max(log10(ESOld.Global.Biome(k).Value));
        if a==-Inf
            a=-4;
        end
        for m=1:24
            ES.Global.Biome(k).Service(m).Value=TE{idk & TE.TEEB_ES==m,85};
            ES.Global.Biome(k).Service(m).Name = Service_Name{m};
            if any(idk & TE.TEEB_ES==m) || ~isempty(ESOld.Global.Biome(k).Service(m).Value)
                subplot(6,4,m);
                histogram(log10(ES.Global.Biome(k).Service(m).Value),20,'Binwidth',(b-a)/20,'FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]);
                hold on
                [C,IA,IB]=setxor(ES.Global.Biome(k).Service(m).Value,ESOld.Global.Biome(k).Service(m).Value);
                histogram(log10(C),20,'Binwidth',(b-a)/20,'FaceColor',[0.66 0 0],'EdgeColor',[0 0 0]);
                xlim([a b]);
                xlabel(['log(ESV) m=' num2str(m) ' - ' ES.Global.Biome(k).Service(m).Name]);
            end
        end  
        sgtitle(['Biome k=' num2str(k) ' (' Biome_Name{k} ')']) 
    end
end

%plot variance of total in biome global values

ESVDmeans=[0;63985;64606;14177;36407;4072;3422;1818;1927];

figure
set(gcf,'Color',[1 1 1]);
tilef = tiledlayout(4,2,'TileSpacing','compact','Padding','compact');
for k=2:9
    EValue=zeros(1,n_sam);
    TValue=zeros(23,1);
    nt=length(ES.Global.Biome(k).Service(24).Value);
    for j=1:n_sam %(n_sam-nt)
        TValue=zeros(23,1);
        for m=1:23
            %choose a value at random from ecosystem service
            n=length(ES.Global.Biome(k).Service(m).Value);
            if ~(n==0)
                TValue(m,1)=ES.Global.Biome(k).Service(m).Value(randi(n));
            end
        end
        EValue(1,j) = sum(TValue);
    end
    %EValue(1,(n_sam-nt+1:n_sam))= ES.Global.Biome(k).Service(24).Value;
    if k==2 || k ==3
        correction=EValue<5*10^5; 
    else
        correction=1:n_sam;
    end
    ES.Global.Biome(k).Value=EValue;
    %
    nexttile
    histogram(ES.Global.Biome(k).Value(correction),20,'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]); 
    y=ylim;
    hold on
    box off
    ax = gca;
    ax.XAxis.Exponent = 0;
    xtickformat('%.0f')
    plot([ESVDmeans(k) ESVDmeans(k)],[y(1) y(2)],'Color','k','LineStyle','--','LineWidth',2);
    plot([mean(ES.Global.Biome(k).Value(correction)) mean(ES.Global.Biome(k).Value(correction))],[y(1) y(2)],'Color','k','LineStyle','-','LineWidth',1);
    xlabel('Distribution of value USD2020 PPP / ha / yr')
    title(['Biome k=' num2str(k) ' (' Biome_Name{k} ')'])  
    ylim(y);
end

% reassmble country values

ES.Country=struct();

xtract1=@(x)(floor(10.00001*(x-floor(x))));

%country
id_val=unique(TE.Country_Code_1);
for i=1:length(id_val)
    id_vali = ismember(TE.Country_Code_1,id_val(i));
    i101=find(ismember(T10401.CountryCode,id_val(i)));
    ES.Country(i101).Name=id_val(i);
    %biomes with valuation in country i
    idbm=unique(TE.Biome_Code(id_vali));
    for k=1:length(idbm)
        id_valik = id_vali & TE.Biome_Code==idbm(k);
        ES.Country(i101).Biome(idbm(k)).Name=idbm(k);
        %ecosystems in biome k  with valuation in country i
        idec=unique(TE.Ecosystem_Code(id_valik));
        for j=1:length(idec)
            id_valikj=id_valik & TE.Ecosystem_Code==idec(j);
            ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Name=idbm(k)+0.1*extract1(idec(j));
            %services in ecosystem j in biome k  with valuation in country i
            idsv=unique(TE.TEEB_ES(id_valikj));
            for m=1:length(idsv)
                id_valikjm = id_valikj & TE.TEEB_ES==idsv(m);
                ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Service(idsv(m)).Name=idsv(m);
                ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Service(idsv(m)).Value=TE{id_valikjm,85};
            end
            %sum random variable services to ecosystem
            EValue=zeros(1,n_sam);
            for p=1:n_sam %(n_sam-nt)
                TValue=zeros(length(idsv),1);
                for m=1:length(idsv)
                    %choose a value at random from ecosystem service
                    n=length(ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Service(idsv(m)).Value);
                    if ~(n==0)
                        TValue(m,1)=ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Service(idsv(m)).Value(randi(n));
                    end
                end
                EValue(1,p) = sum(TValue);
            end
            ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Value=EValue;
        end
        %sum random variable services to biome
        EValue=zeros(1,n_sam);
        for p=1:n_sam %(n_sam-nt)
            TValue=zeros(length(idec),1);
            for m=1:length(idec)
                %choose a value at random from ecosystem service
                n=length(ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Value);
                if ~(n==0)
                    TValue(m,1)=ES.Country(i101).Biome(idbm(k)).Ecosystem(extract1(idec(j))).Value(randi(n));
                end
            end
            EValue(1,p) = sum(TValue);
        end
        ES.Country(i101).Biome(idbm(k)).Value=EValue;   
        ES.Country(i101).Biome(idbm(k)).LMean=mean(log10(EValue));   
        ES.Country(i101).Biome(idbm(k)).LStd=std(log(EValue)); 
    end
    ES.Country(i101).X = [log10(T10401.PopDensity(i101)) log10(T10401.GNI(i101)) T10401.HDI(i101) T10401.FPer(i101) T10401.APer(i101) T10401.MProt(i101) T10401.LProt(i101)];
    ES.Country(i101).HDI = 0;
    if T10401.HDI(i101)>0 && T10401.HDI(i101)<0.625 %low development
        ES.Country(i101).HDI=1;
    elseif T10401.HDI(i101)>=0.625 && T10401.HDI(i101)<0.75 %moderate development
        ES.Country(i101).HDI=2;
    elseif T10401.HDI(i101)>=0.75 && T10401.HDI(i101)<0.89
        ES.Country(i101).HDI=3; %high development
    elseif T10401.HDI(i101)>=0.89
        ES.Country(i101).HDI=4; %very high development
    end
end

%% ESVD HDI Grouping

%hdi
idhd=~cellfun(@isempty,{ES.Country.HDI}');

EValue = zeros(1,n_sam);
EValueS = zeros(1,n_sam);

n_sam = 10000;

for k=2:9
    for i=1:4
        %find the hdi index
        idhdi_temp=[ES.Country(idhd).HDI]'==i;
        idhdi=idhd;
        idhdi(idhdi)=idhdi_temp;
        idhdi_f=find(idhdi);
        ES.HDI(i).Name=i;
        ES.HDI(i).Biome(k).Name=Biome_Name{k};
        EValue1=[];
        EValue2=[];
        EValue3=[];
        ES.HDI(i).Biome(k).AService(1).Name='Provisioning';
        ES.HDI(i).Biome(k).AService(2).Name='Regulating';
        ES.HDI(i).Biome(k).AService(3).Name='Cultural';
        ES.HDI(i).Biome(k).Service = ES.Global.Biome(k).Service;
        % reset value
        for m = 1:size(ES.Global.Biome(k).Service,2)
            ES.HDI(i).Biome(k).Service(m).Value=[];
        end
        % assign values
        for j=1:length(idhdi_f)
            idhdi_bm=[ES.Country(idhdi_f(j)).Biome.Name]'==k;
            if any(idhdi_bm)
                for s=1:size(ES.Country(idhdi_f(j)).Biome(k).Ecosystem,2)
                    if ~isempty(ES.Country(idhdi_f(j)).Biome(k).Ecosystem(s).Name)                        
                        idsv=find(~cellfun(@isempty,{ES.Country(idhdi_f(j)).Biome(k).Ecosystem(s).Service.Name}'));
                        for m=1:length(idsv)
                            % ecosystem services
                            ES.HDI(i).Biome(k).Service(idsv(m)).Value = [ES.HDI(i).Biome(k).Service(idsv(m)).Value ; ES.Country(idhdi_f(j)).Biome(k).Ecosystem(s).Service(idsv(m)).Value];                   
                            % ecosystem functions (Aggregated Services)
                            if idsv(m) >=1 && idsv(m) <=6
                                EValue1=[EValue1;ES.Country(idhdi_f(j)).Biome(k).Ecosystem(s).Service(idsv(m)).Value];
                            end
                            if idsv(m) >=7 && idsv(m) <=17
                                EValue2=[EValue2;ES.Country(idhdi_f(j)).Biome(k).Ecosystem(s).Service(idsv(m)).Value];
                            end
                            if idsv(m) >=18 && idsv(m) <=23
                                EValue3=[EValue3;ES.Country(idhdi_f(j)).Biome(k).Ecosystem(s).Service(idsv(m)).Value];
                            end
                        end
                    end
                end
            end
        end
        ES.HDI(i).Biome(k).AService(1).Value=EValue1;
        ES.HDI(i).Biome(k).AService(2).Value=EValue2;
        ES.HDI(i).Biome(k).AService(3).Value=EValue3;
        %make distribution samples
        for p=1:n_sam %(n_sam-nt)
            TValue=zeros(3,1);
            for m=1:3
                %choose a value at random from ecosystem service
                n=size(ES.HDI(i).Biome(k).AService(m).Value,1);
                if ~(n==0)
                    TValue(m,1)=ES.HDI(i).Biome(k).AService(m).Value(randi(n));
                end
            end
            EValue(1,p) = sum(TValue);
            %
            TValue=zeros(23,1);
            for m=1:23
                %choose a value at random from ecosystem service
                n=size(ES.HDI(i).Biome(k).Service(m).Value,1);
                if ~(n==0)
                    TValue(m,1)=ES.HDI(i).Biome(k).Service(m).Value(randi(n));
                end
            end
            EValueS(1,p) = sum(TValue);
        end
        ES.Global.Biome(k).HDI(i).Name=i;
        ES.Global.Biome(k).HDI(i).Value=EValue;
        ES.Global.Biome(k).HDI(i).ValueS=EValueS;
    end
    ES.Global.Biome(k).AService(1).Name='Provisioning';
    ES.Global.Biome(k).AService(2).Name='Regulating';
    ES.Global.Biome(k).AService(3).Name='Cultural';
    ES.Global.Biome(k).AService(1).Value=[ES.HDI(1).Biome(k).AService(1).Value;ES.HDI(2).Biome(k).AService(1).Value;ES.HDI(3).Biome(k).AService(1).Value;ES.HDI(i).Biome(k).AService(1).Value];
    ES.Global.Biome(k).AService(2).Value=[ES.HDI(1).Biome(k).AService(2).Value;ES.HDI(2).Biome(k).AService(2).Value;ES.HDI(3).Biome(k).AService(2).Value;ES.HDI(i).Biome(k).AService(2).Value];
    ES.Global.Biome(k).AService(3).Value=[ES.HDI(1).Biome(k).AService(3).Value;ES.HDI(2).Biome(k).AService(3).Value;ES.HDI(3).Biome(k).AService(3).Value;ES.HDI(i).Biome(k).AService(3).Value];
end

n_sam = 1000;

% figures for HDI grouping

for k=2:9
    %by HDI
    figure
    set(gcf,'Color',[1 1 1]);
    hold on
    maxV=zeros(1,3);
    minV=zeros(1,3);
    for j=1:3
        maxV(j)=max(log10(ES.Global.Biome(k).AService(j).Value));
        minV(j)=min(log10(ES.Global.Biome(k).AService(j).Value));
        if minV(j)==-Inf
            minV(j)=-4;
        end
    end
    for i=1:4
        for j=1:3
            subplot(4,3,(i-1)*3 + j)
            histogram(log10(ES.HDI(i).Biome(k).AService(j).Value),20,'Binwidth',(maxV(j)-minV(j))/20,'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]);
            xlim([minV(j), maxV(j)]);
            y=ylim;
            hold on
            plot([mean(log10(ES.HDI(i).Biome(k).AService(j).Value)) mean(log10(ES.HDI(i).Biome(k).AService(j).Value))],[y(1) y(2)],'k--','LineWidth',2);
            xlabel('Distribution of value US$2020 PPP / ha /yr')
            title(['HDI=' num2str(i) ' ' ES.HDI(i).Biome(k).AService(j).Name])
        end
    end
    sgtitle(['Biome k=' num2str(k) ' (' Biome_Name{k} ')']);
    %by service
    figure
    set(gcf,'Color',[1 1 1]);
    for j=1:3
    maxV(j)=max(log10(ES.Global.Biome(k).AService(j).Value));
    minV(j)=min(log10(ES.Global.Biome(k).AService(j).Value));
    if minV(j)==-Inf
            minV(j)=-4;
    end
    subplot(1,3,j)
            histogram(log10(ES.Global.Biome(k).AService(j).Value),20,'Binwidth',(maxV(j)-minV(j))/20,'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]);
            xlim([minV(j), maxV(j)]);
            y=ylim;
            hold on
            plot([mean(log10(ES.Global.Biome(k).AService(j).Value)) mean(log10(ES.Global.Biome(k).AService(j).Value))],[y(1) y(2)],'k--','LineWidth',2);
            xlabel('Distribution of value US$2020 PPP / ha /yr')
            title(ES.HDI(i).Biome(k).AService(j).Name)
    end
    sgtitle(['Biome k=' num2str(k) ' (' Biome_Name{k} ')']);
    %by hdi
    figure
    set(gcf,'Color',[1 1 1]);
    maxV=max(maxV);
    minV=min(minV);
    if minV==-Inf
            minV=-4;
    end
    for i=1:4
        subplot(4,1,i)
        histogram(log10(ES.Global.Biome(k).HDI(i).Value),20,'Binwidth',(maxV-minV)/20,'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]);
        xlim([minV, maxV]);
        y=ylim;
        hold on
        plot([mean(log10(ES.Global.Biome(k).HDI(i).Value)) mean(log10(ES.Global.Biome(k).HDI(i).Value))],[y(1) y(2)],'k--','LineWidth',2);
        xlabel('Distribution of value US$2020 PPP / ha /yr')
        title(['HDI=' num2str(i)])
    end
    sgtitle(['Biome k=' num2str(k) ' (' Biome_Name{k} ')']);
end

%global in log10
figure
set(gcf,'Color',[1 1 1]);
hold on
for k=2:9
    EValue=zeros(1,n_sam);
    TValue=zeros(23,1);
    nt=length(ES.Global.Biome(k).Service(24).Value);
    for j=1:n_sam %(n_sam-nt)
        TValue=zeros(23,1);
        for m=1:23
            %choose a value at random from ecosystem service
            n=length(ES.Global.Biome(k).Service(m).Value);
            if ~(n==0)
                TValue(m,1)=ES.Global.Biome(k).Service(m).Value(randi(n));
            end
        end
        EValue(1,j) = sum(TValue);
    end
    %EValue(1,(n_sam-nt+1:n_sam))= ES.Global.Biome(k).Service(24).Value;
%     if k==2 || k ==3
%         correction=EValue<5*10^5; 
%     else
%         correction=1:n_sam;
%     end
    ES.Global.Biome(k).Value=EValue;
    subplot(3,3,k-1)
    histogram(log10(ES.Global.Biome(k).Value),20,'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]); 
    y=ylim;
    hold on
    plot([mean(log10(ES.Global.Biome(k).Value)) mean(log10(ES.Global.Biome(k).Value))],[y(1) y(2)],'k--');
    xlabel('Distribution of value US$2020 PPP / ha /yr')
    title(['Biome k=' num2str(k) ' (' Biome_Name{k} ')'])  
end

% comparison Value (HDI-EFRS) and Value2 (HDI-ESRC)

ESVDmeans=[0;63985;64606;14177;36407;4072;3422;1818;1927];

xlimS = [6;6;6;6;4.5;4.5;4.5;4.5];

% raw samples

figure
set(gcf,'Color',[1 1 1]);
tilef = tiledlayout(8,4,'TileSpacing','compact','Padding','compact');
for k=2:9
    for i=1:4
        %
        nexttile
        histogram(log10(ES.Global.Biome(k).HDI(i).Value),20,'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0 0 0]);
        hold on
        histogram(log10(ES.Global.Biome(k).HDI(i).ValueS),20,'Normalization','pdf','FaceColor',[0.66 0 0],'EdgeColor',[0 0 0]);
        box off
        y=ylim;
        ax = gca;
        %plot([mean(log10(ES.Global.Biome(k).HDI(i).ValueS)) mean(log10(ES.Global.Biome(k).HDI(i).ValueS))],[y(1) y(2)],'Color','k','LineStyle','--','LineWidth',2);
        xlabel('log10(USD2020 PPP / ha / yr)')
        title(['Biome k=' num2str(k) ' HDI ' num2str(i)])
        ylim(y);
        xlim([0, xlimS(k-1)]);
    end
end

% parameterized samples without similarity pooling

outlier_limit = 10^6;

figure
set(gcf,'Color',[1 1 1]);
tilef = tiledlayout(8,4,'TileSpacing','compact','Padding','compact');
for k=2:9
    for i=1:4
        %
        par_value = normrnd(mean(log10(ES.Global.Biome(k).HDI(i).Value)),std(log10(ES.Global.Biome(k).HDI(i).Value)),1,n_sam);
        par_value = par_value(10.^par_value < outlier_limit);
        par_valueS = normrnd(mean(log10(ES.Global.Biome(k).HDI(i).ValueS)),std(log10(ES.Global.Biome(k).HDI(i).ValueS)),1,n_sam);
        par_valueS = par_valueS(10.^par_valueS < outlier_limit);
        %
        nexttile
        if ~( isnan(prctile(10.^par_value,95)) || isnan(prctile(10.^par_valueS,95)) )
            xmax = max(prctile(10.^par_value,95),prctile(10.^par_valueS,95));
            xmin = min(prctile(10.^par_value,0.2),prctile(10.^par_valueS,0.2));
            histogram(10.^par_value,'BinWidth', (xmax - xmin)/100, 'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0.66 0.66 0.66]);
            hold on
            histogram(10.^par_valueS,'BinWidth', (xmax - xmin)/100,'Normalization','pdf','FaceColor',[0.66 0 0],'EdgeColor',[0.66 0 0]);
            box off
            y=ylim;
            ax = gca;
            plot([mean(10.^par_value) mean(10.^par_value)],[y(1) y(2)],'Color','k','LineStyle','-','LineWidth',2);
            plot([mean(ES.Global.Biome(k).HDI(i).Value(ES.Global.Biome(k).HDI(i).Value<outlier_limit)) mean(ES.Global.Biome(k).HDI(i).Value(ES.Global.Biome(k).HDI(i).Value<outlier_limit))],[y(1) y(2)],'Color','k','LineStyle','--','LineWidth',2);
            plot([mean(10.^par_valueS) mean(10.^par_valueS)],[y(1) y(2)],'Color','r','LineStyle','-','LineWidth',2);
            plot([mean(ES.Global.Biome(k).HDI(i).ValueS(ES.Global.Biome(k).HDI(i).ValueS<outlier_limit)) mean(ES.Global.Biome(k).HDI(i).ValueS(ES.Global.Biome(k).HDI(i).ValueS<outlier_limit))],[y(1) y(2)],'Color','r','LineStyle','--','LineWidth',2);
            %plot([ESVDmeans(k) ESVDmeans(k)],[y(1) y(2)],'Color','b','LineStyle','-','LineWidth',2);
            xlabel('USD2020 PPP / ha / yr')
            title(['Biome k=' num2str(k) ' HDI ' num2str(i)])
            ylim(y);
            xlim([0,xmax]);
        end
    end
end


%% ESVD HDI ANOVA and AD bootstrap

ESA=table();
ESA_ANOVA=table();

n_boot = 1000;
alpha_AD = 0.05;
alpha_ANOVA = 0.0001;

%k=2
for k=2:9
    Y=[];
    group=[];
    for i=1:4
        esarow=(k-2)*4 + i;
        %resample with original number of valuations
        n_s=size(ES.HDI(i).Biome(k).AService(1).Value,1)+ ...
            size(ES.HDI(i).Biome(k).AService(2).Value,1)+ ...
            size(ES.HDI(i).Biome(k).AService(3).Value,1);
        % set up table
        ESA.Biome(esarow)=k;
        ESA.HDI(esarow)=i;
        ESA.SampleSize(esarow)=n_s;
        ESA.ADtest_per(esarow) = NaN;
        ESA.LMean_M(esarow) = NaN;
        ESA.ANOVA_per(esarow) = NaN;
        % gname
        % bootstrap
        if n_s > 4
        gname=['HDI' num2str(i)];
        group_temp=cell(1,n_s);
        group_temp(:)={gname};
        group=[group,group_temp];
            EValue=zeros(n_boot,n_s);
            for r = 1:n_boot
                for p=1:n_s
                    TValue=zeros(3,1);
                    for m=1:3
                        %choose a value at random from ecosystem service
                        n=size(ES.HDI(i).Biome(k).AService(m).Value,1);
                        if ~(n==0)
                            TValue(m,1)=ES.HDI(i).Biome(k).AService(m).Value(randi(n));
                        end
                    end
                    EValue(r,p) = sum(TValue);
                end
                [~,p] = adtest(log10(EValue(r,:)));
                ESA.ADtest_p(esarow,r) = p;
                ESA.LMean(esarow,r)=mean(log10(EValue(r,:)));                
            end
            Y=[Y,log10(EValue)];
            ESA.ADtest_per(esarow) = sum(ESA.ADtest_p(esarow,:) < alpha_AD)/n_boot;
            ESA.LMean_M(esarow) = mean(ESA.LMean(esarow,:));
            ESA.LMean_5(esarow) = prctile(ESA.LMean(esarow,:),5);
            ESA.LMean_95(esarow) = prctile(ESA.LMean(esarow,:),95);
        end
    end
    %anova
    %are means same population
    ESA_ANOVA_temp=table();
    for r=1:n_boot
        [p,~,stats] = anova1(Y(r,:),group,'off');
        ESA.ANOVA_p(ESA.Biome==k,r)=p;
        %what are means?
        [c,~,~,~] = multcompare(stats,'Display','off');
        if r==1
            ESA_ANOVA_temp.Biome(1:size(c,1)) = k;
            ESA_ANOVA_temp.HDI_tier_compare = c(:,1:2);
            ESA_ANOVA_temp.Pairwise_per = NaN(size(c,1),1);
        end
        ESA_ANOVA_temp.Pairwise_p(:,r) = c(:,6);
    end
    ESA_ANOVA_temp.Pairwise_per = sum(ESA_ANOVA_temp.Pairwise_p < alpha_AD,2)/n_boot;
    ESA_ANOVA = [ESA_ANOVA; ESA_ANOVA_temp];
    ESA.ANOVA_per(ESA.Biome==k) = sum(ESA.ANOVA_p(ESA.Biome==k,:) < alpha_ANOVA,2)/n_boot;
end

ESA = movevars(ESA,'LMean_M','After','SampleSize');
ESA = movevars(ESA,{'LMean_5','LMean_95'},'After','LMean_M');

% plot HDI ESV Kusnetz

figure
set(gcf,'Color',[1 1 1]);

h=[];
minh=0;
maxh=0;

for k=[2:4 6:9]

    idk = ESA.Biome==k;
    x=1:4;
    y=ESA.LMean_M(idk);
    neg=ESA.LMean_M(idk)-ESA.LMean_5(idk);
    pos=ESA.LMean_95(idk)-ESA.LMean_M(idk);
    h(k) = errorbar(x,y,neg,pos);
    set(h(k),'DisplayName',Biome_Name{k});
    hold on

    minh = min(minh,min(0,min(y-neg)));
    maxh = max(maxh,max(0,max(y+pos)));

end

xlim([0.9,4.1]);
ylim([minh,maxh]);
box off
ax = gca;
legend('Location','');
ax.XTick = [1 2 3 4];
ax.XTickLabel={'HDI 1','HDI 2','HDI 3','HDI 4'} ;   
ax.XGrid = 'on';
xlabel('HDI tier');
ylabel('E(log10(ESV))');
title(['Mean of log10 transform of ESV by HDI level'])


%% Choice of parameterised distribution for HDI Teir

w_hdi=zeros(9,4,4);  %k, hdi, sampling weights

w_hdi(2,1,:)=[1 0 0 0]*1000; 
w_hdi(2,2,:)=[0 1 1 0]*1000; 
w_hdi(2,3,:)=[0 1 1 0]*1000; 
w_hdi(2,4,:)=[0 0 0 1]*1000; 
w_hdi(3,1,:)=[1 0 0 0]*1000;
w_hdi(3,2,:)=[0 1 0 0]*1000;
w_hdi(3,3,:)=[0 0 1 0]*1000;
w_hdi(3,4,:)=[0 0 0 1]*1000;
w_hdi(4,1,:)=[1 0 0 0]*1000;
w_hdi(4,2,:)=[0 1 1 0]*1000;
w_hdi(4,3,:)=[0 1 1 0]*1000; 
w_hdi(4,4,:)=[0 0 0 1]*1000;
w_hdi(5,1,:)=[1 1 0 0];
w_hdi(5,2,:)=[1 1 0 0]*1000;
w_hdi(5,3,:)=[0 0 1 1]*1000;
w_hdi(5,4,:)=[0 0 1 1]*1000;
w_hdi(6,1,:)=[1 1 1 0]*1000; 
w_hdi(6,2,:)=[1 1 1 0]*1000; 
w_hdi(6,3,:)=[1 1 1 0]*1000; 
w_hdi(6,4,:)=[1 1 1 0]*1000; 
w_hdi(7,1,:)=[0 0 1 1]*1000; 
w_hdi(7,2,:)=[0 0 1 1]*1000; 
w_hdi(7,3,:)=[0 0 1 1]*1000; 
w_hdi(7,4,:)=[0 0 1 1]*1000; 
w_hdi(8,1,:)=[0 0 1 0]*1000; 
w_hdi(8,2,:)=[0 0 1 0]*1000; 
w_hdi(8,3,:)=[0 0 1 0]*1000; 
w_hdi(8,4,:)=[0 0 0 1]*1000; 
w_hdi(9,1,:)=[0 0 1 0]*1000; %pooled
w_hdi(9,2,:)=[0 0 1 0]*1000; %pooled
w_hdi(9,3,:)=[0 0 1 0]*1000; %pooled
w_hdi(9,4,:)=[0 0 0 1]*1000; %pooled


%% Re-build adjusting for build ESPI Index

ESP=table();

%% Re-sample ES based on ANOVA results

for k=2:9
    EValue=zeros(4,size(ES.Global.Biome(k).HDI(1).Value,2));
    for j=1:4
        EValue(j,:)=log10(ES.Global.Biome(k).HDI(j).Value);
    end
    for i=1:4
        w=squeeze(w_hdi(k,i,:)/sum(w_hdi(k,i,:)));
        % re-sample
        rsamp = [randsample(size(EValue,1),n_sam,true,w), randi(size(ES.Global.Biome(k).HDI(j).Value,2),n_sam,1)];
        EValue_r=EValue(sub2ind(size(EValue),rsamp(:,1),rsamp(:,2)))';
        % store
        c=(k-2)*4+i;
        ESP.Biome(c)=k;
        ESP.HDI(c)=i;
        % check for nans
        if any(isnan(mean(EValue,2)))
            if ~all(w(isnan(mean(EValue,2)))==0)
               error("Weights are non-zero");
            end
        end
        %
        ESP.mu(c) = sum(w.*mean(EValue,2),'omitnan'); %log10
        ESP.sigma(c) = sqrt(sum(w.*mean(EValue.^2,2),'omitnan')-ESP.mu(c)^2); %log10
        ESP.checkmu(c,:) = mean(EValue_r);
        ESP.checksigma(c,:) = std(EValue_r);
        ESP.mucompare(c)=mean(log10(ES.Global.Biome(k).HDI(i).Value));
        ESP.stdcompare(c)=std(log10(ES.Global.Biome(k).HDI(i).Value));
        ESP.Value(c,:) = EValue_r;
    end
end
    
% smoothed EF versus raw ES comparison

outlier_limit = 10^6;

ESH=table();

figure
set(gcf,'Color',[1 1 1]);
tilef = tiledlayout(8,4,'TileSpacing','compact','Padding','compact');
for k=2:9
    for i=1:4
        esarow=(k-2)*4 + i;
        idp = ESP.Biome == k & ESP.HDI == i;
        % set up table
        ESH.Biome(esarow)=k;
        ESH.HDI(esarow)=i;
        %
        par_value = normrnd(ESP.mu(idp),ESP.sigma(idp),1,n_sam);
        par_value = par_value(10.^par_value < outlier_limit);
        %
        ESH.Mean_EF(esarow)=mean(10.^par_value);
        ESH.Std_EF(esarow)=std(10.^par_value);
        ESH.Mean_ES_raw(esarow) = mean(ES.Global.Biome(k).HDI(i).ValueS(ES.Global.Biome(k).HDI(i).ValueS<outlier_limit));
        ESH.Std_ES_raw(esarow) = std(ES.Global.Biome(k).HDI(i).ValueS(ES.Global.Biome(k).HDI(i).ValueS<outlier_limit));
        ESH.Mean_Compare(esarow) = 1-ESH.Mean_EF(esarow)/ESH.Mean_ES_raw(esarow);
        ESH.High_Compare(esarow) = 1- ESH.Mean_ES_raw(esarow)./prctile(10.^par_value,95);
        ESH.Low_Compare(esarow) = sum(10.^par_value < ESH.Mean_ES_raw(esarow))/sum(10.^par_value < Inf);
        ESH.Mean_Compare_Global(esarow) = 1-ESH.Mean_EF(esarow)/ESVDmeans(k);
        ESH.High_Compare_Global(esarow) = prctile(10.^par_value,95)/ESVDmeans(k)-1;
        %
        nexttile
        if true
            xmax = max(prctile(10.^par_value,95),prctile(ES.Global.Biome(k).HDI(i).ValueS,95));
            xmin = min(prctile(10.^par_value,0.2),prctile(ES.Global.Biome(k).HDI(i).ValueS,0.2));
            histogram(10.^par_value,'BinWidth', (xmax - xmin)/100, 'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0.66 0.66 0.66]);
            hold on
            histogram(ES.Global.Biome(k).HDI(i).ValueS(ES.Global.Biome(k).HDI(i).ValueS < outlier_limit),'BinWidth', (xmax - xmin)/100,'Normalization','pdf','FaceColor',[0.66 0 0],'EdgeColor',[0.66 0 0]);
            box off
            y=ylim;
            ax = gca;
            plot([ESH.Mean_EF(esarow) ESH.Mean_EF(esarow)],[y(1) y(2)],'Color','k','LineStyle','-','LineWidth',2);
            %plot([ESH.Mean_EF_raw(esarow) ESH.Mean_EF_raw(esarow)],[y(1) y(2)],'Color','k','LineStyle','--','LineWidth',2);
            plot([ESH.Mean_ES_raw(esarow) ESH.Mean_ES_raw(esarow)],[y(1) y(2)],'Color','r','LineStyle','-','LineWidth',2);
            %plot([ESH.Mean_ES_raw(esarow) ESH.Mean_ES_raw(esarow)],[y(1) y(2)],'Color','r','LineStyle','--','LineWidth',2);
            %plot([ESVDmeans(k) ESVDmeans(k)],[y(1) y(2)],'Color','b','LineStyle','-','LineWidth',2);
            xlabel('USD2020 PPP / ha / yr')
            title(['Biome k=' num2str(k) ' HDI ' num2str(i)])
            ylim(y);
            xlim([0,xmax]);
        end
    end
end

ESH = movevars(ESH,'Mean_ES_raw','After','Mean_EF');

% comparison log10

figure
set(gcf,'Color',[1 1 1]);
tilef = tiledlayout(8,4,'TileSpacing','compact','Padding','compact');
for k=2:9
    for i=1:4
        idp = ESP.Biome == k & ESP.HDI == i;
        %
        par_value = normrnd(ESP.mu(idp),ESP.sigma(idp),1,n_sam);
        par_value = par_value(10.^par_value < outlier_limit);
        par_valueS = log10(ES.Global.Biome(k).HDI(i).ValueS(ES.Global.Biome(k).HDI(i).ValueS < outlier_limit));
        %
        nexttile
        if ~( any(par_value==-Inf) || any(isempty(par_value)) || any(par_valueS==-Inf) || any(isempty(par_valueS)) )
            xmax = log10(max(prctile(10.^par_value,98),prctile(ES.Global.Biome(k).HDI(i).ValueS,98)));
            xmin = log10(min(prctile(10.^par_value,0.2),prctile(ES.Global.Biome(k).HDI(i).ValueS,0.2)));
            histogram(par_value,'BinWidth', (xmax - xmin)/30, 'Normalization','pdf','FaceColor',[0.66 0.66 0.66],'EdgeColor',[0.66 0.66 0.66]);
            hold on
            histogram(par_valueS,'BinWidth', (xmax - xmin)/30,'Normalization','pdf','FaceColor',[0.66 0 0],'EdgeColor',[0.66 0 0]);
            box off
            y=ylim;
            ax = gca;
            plot([mean(par_value) mean(par_value)],[y(1) y(2)],'Color','k','LineStyle','-','LineWidth',2);
            %plot([ESH.Mean_EF_raw(esarow) ESH.Mean_EF_raw(esarow)],[y(1) y(2)],'Color','k','LineStyle','--','LineWidth',2);
            plot([mean(par_valueS) mean(par_valueS)],[y(1) y(2)],'Color','r','LineStyle','-','LineWidth',2);
            %plot([ESH.Mean_ES_raw(esarow) ESH.Mean_ES_raw(esarow)],[y(1) y(2)],'Color','r','LineStyle','--','LineWidth',2);
            %plot([ESVDmeans(k) ESVDmeans(k)],[y(1) y(2)],'Color','b','LineStyle','-','LineWidth',2);
            xlabel('log10(USD2020PPP/ha/yr')
            title(['Biome k=' num2str(k) ' HDI ' num2str(i)])
            ylim(y);
            xlim([0,xmax]);
        end
    end
end
 